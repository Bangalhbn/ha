# Perintah termux :
    $ pkg update && pkg upgrade
    $ pkg install git
    $ pkg install python3
    $ git clone https://github.com/RozhakXD/Fb-Crack
    $ cd Fb-Crack
    $ pip3 install -r requirements.txt
    $ chmod +x true && ./true
# Update script :
    $ rm -rf $HOME/Fb-Crack
    $ git clone https://github.com/RozhakXD/Fb-Crack
    $ cd Fb-Crack
    $ chmod +x true && ./true
